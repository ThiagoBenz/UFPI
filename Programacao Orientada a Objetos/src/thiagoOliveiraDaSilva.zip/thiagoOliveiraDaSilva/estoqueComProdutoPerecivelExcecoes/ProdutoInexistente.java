package thiagoOliveiraDaSilva.estoqueComProdutoPerecivelExcecoes;

public class ProdutoInexistente extends Exception {
	public ProdutoInexistente() {
		super("produto  inexistente!");
	}

}
