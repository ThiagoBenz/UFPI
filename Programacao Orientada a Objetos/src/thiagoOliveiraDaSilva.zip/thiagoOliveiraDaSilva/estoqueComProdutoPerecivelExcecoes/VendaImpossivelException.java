package thiagoOliveiraDaSilva.estoqueComProdutoPerecivelExcecoes;

public class VendaImpossivelException extends Exception {
	public VendaImpossivelException() {
		super("venda impossivel");
	}
}
