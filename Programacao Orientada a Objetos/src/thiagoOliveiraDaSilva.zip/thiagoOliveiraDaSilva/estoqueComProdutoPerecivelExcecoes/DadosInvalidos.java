package thiagoOliveiraDaSilva.estoqueComProdutoPerecivelExcecoes;

public class DadosInvalidos extends Exception {
	public DadosInvalidos() {
		super("dados invalidos!");
	}

}
