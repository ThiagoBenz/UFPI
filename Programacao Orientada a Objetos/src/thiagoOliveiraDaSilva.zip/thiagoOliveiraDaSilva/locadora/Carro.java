package thiagoOliveiraDaSilva.locadora;

public class Carro extends Veiculo {
	private int categoria;
	

	/**
	 * @return the categoria
	 */
	public int getCategoria() {
		return categoria;
	}

	/**
	 * @param categoria the categoria to set
	 */
	public void setCategoria(int categoria) {
		this.categoria = categoria;
	}

	public Carro(String marca, String modelo, int ano, double valorBem , double valorDiaria ,
			String placa, int categoria) {
		
		this.setMarca(marca);
		this.setModelo(modelo);
		this.setAnoFabricacao(ano);
		this.setValorBem(valorBem);
		this.setValorDiaria(valorDiaria);
		this.setCategoria(categoria);
		this.setPlaca(placa);
	}

	@Override
	public double calcularAluguel(String placa, int dias) {
		// TODO Auto-generated method stub
		Veiculo veiculo =  pesquisa(placa);
		if (veiculo == null) {
			return -1;
		}
		double diaria = veiculo.getValorDiaria();
		 this.setSeguro((this.getValorAvaliado() * (3 / 100)) / 365);
		
		return (diaria+ getSeguro())*dias;
	}

}
